"""
Dry Run - mock data generator.
Produces Synthea-shaped CSVs (same column names as real Synthea CSV export)
so the engine can switch to real Synthea data with zero code changes.

Usage:  python generate_mock.py [N_PATIENTS]   (default 2000)
"""
import csv, json, os, random, sys, uuid
from datetime import date, timedelta

random.seed(42)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
INDEX_DATE = date(2026, 10, 1)          # "today" for every lookback window
OUT = os.path.join(os.path.dirname(__file__), "patients")
os.makedirs(OUT, exist_ok=True)

# ---- code dictionary (also written to codes.json) -------------------------
CODES = {
    "loinc": {
        "hba1c": {"code": "4548-4", "desc": "Hemoglobin A1c/Hemoglobin.total in Blood"},
        "bmi": {"code": "39156-5", "desc": "Body mass index (BMI) [Ratio]"},
        "egfr": {"code": "33914-3", "desc": "Glomerular filtration rate/1.73 sq M.predicted"},
        "weight": {"code": "29463-7", "desc": "Body Weight"},
    },
    "snomed": {
        "t2dm": {"code": "44054006", "desc": "Diabetes mellitus type 2"},
        "t1dm": {"code": "46635009", "desc": "Diabetes mellitus type 1"},
        "mi": {"code": "22298006", "desc": "Myocardial infarction"},
        "stroke": {"code": "230690007", "desc": "Cerebrovascular accident"},
        "pancreatitis": {"code": "197456007", "desc": "Acute pancreatitis"},
        "ckd_dialysis": {"code": "MOCK-DIALYSIS", "desc": "Dependence on renal dialysis"},
        "hypertension": {"code": "38341003", "desc": "Hypertension"},
        "malignancy": {"code": "MOCK-CANCER", "desc": "Malignant neoplasm"},
        "retinopathy_prolif": {"code": "MOCK-PDR", "desc": "Proliferative diabetic retinopathy"},
    },
    "note": "MOCK-* codes are placeholders. Swap for real SNOMED codes when moving to real Synthea output.",
}

def d(days_ago):  # date string N days before index date
    return (INDEX_DATE - timedelta(days=days_ago)).isoformat()

RACES = ["white"] * 70 + ["black"] * 10 + ["asian"] * 8 + ["hispanic_any"] * 0 + ["other"] * 4 + ["native"] * 1
patients, obs, conds, meds = [], [], [], []

for _ in range(N):
    pid = str(uuid.uuid4())
    age = int(min(90, max(19, random.gauss(60, 13))))
    sex = random.choice(["M", "F"])
    birth = INDEX_DATE - timedelta(days=age * 365 + random.randint(0, 364))
    race = random.choice(RACES)
    eth = "hispanic" if random.random() < 0.12 else "nonhispanic"
    patients.append({"Id": pid, "BIRTHDATE": birth.isoformat(), "DEATHDATE": "",
                     "RACE": race, "ETHNICITY": eth, "GENDER": sex,
                     "STATE": "Massachusetts", "COUNTY": random.choice(
                         ["Suffolk County", "Middlesex County", "Worcester County",
                          "Hampden County", "Essex County", "Norfolk County"])})

    # Diabetes type: ~93% T2, ~4% T1, ~3% neither (tests diagnosis rule)
    r = random.random()
    dx = "t2dm" if r < 0.93 else ("t1dm" if r < 0.97 else None)
    if dx:
        conds.append({"START": d(random.randint(400, 7000)), "STOP": "", "PATIENT": pid,
                      "ENCOUNTER": "", "CODE": CODES["snomed"][dx]["code"],
                      "DESCRIPTION": CODES["snomed"][dx]["desc"]})

    # Labs. ~15% missing each (-> "unknown" verdicts). HbA1c sometimes in mmol/mol.
    if random.random() > 0.15:
        a1c = round(min(13.5, max(5.5, random.gauss(8.0, 1.3))), 1)
        days = random.randint(5, 400)            # some fall outside a 90/180-day lookback
        if random.random() < 0.25:              # 25% reported in IFCC units
            obs.append({"DATE": d(days), "PATIENT": pid, "ENCOUNTER": "", "CATEGORY": "laboratory",
                        "CODE": "4548-4", "DESCRIPTION": CODES["loinc"]["hba1c"]["desc"],
                        "VALUE": round(10.929 * (a1c - 2.15), 1), "UNITS": "mmol/mol", "TYPE": "numeric"})
        else:
            obs.append({"DATE": d(days), "PATIENT": pid, "ENCOUNTER": "", "CATEGORY": "laboratory",
                        "CODE": "4548-4", "DESCRIPTION": CODES["loinc"]["hba1c"]["desc"],
                        "VALUE": a1c, "UNITS": "%", "TYPE": "numeric"})
    if random.random() > 0.10:
        bmi = round(min(55, max(19, random.gauss(32, 6))), 1)
        obs.append({"DATE": d(random.randint(5, 300)), "PATIENT": pid, "ENCOUNTER": "", "CATEGORY": "vital-signs",
                    "CODE": "39156-5", "DESCRIPTION": CODES["loinc"]["bmi"]["desc"],
                    "VALUE": bmi, "UNITS": "kg/m2", "TYPE": "numeric"})
    if random.random() > 0.20:
        egfr = round(min(120, max(8, random.gauss(78 - (age - 60) * 0.8, 20))))
        obs.append({"DATE": d(random.randint(5, 400)), "PATIENT": pid, "ENCOUNTER": "", "CATEGORY": "laboratory",
                    "CODE": "33914-3", "DESCRIPTION": CODES["loinc"]["egfr"]["desc"],
                    "VALUE": egfr, "UNITS": "mL/min/{1.73_m2}", "TYPE": "numeric"})

    # Comorbidities (older patients more likely)
    def maybe(key, p, recent=False):
        if random.random() < p:
            days = random.randint(1, 59) if recent else random.randint(61, 6000)
            conds.append({"START": d(days), "STOP": "", "PATIENT": pid, "ENCOUNTER": "",
                          "CODE": CODES["snomed"][key]["code"], "DESCRIPTION": CODES["snomed"][key]["desc"]})
    risk = 1 + max(0, age - 55) / 20
    maybe("hypertension", 0.55)
    maybe("mi", 0.06 * risk); maybe("mi", 0.01, recent=True)
    maybe("stroke", 0.04 * risk); maybe("stroke", 0.005, recent=True)
    maybe("pancreatitis", 0.02)
    maybe("ckd_dialysis", 0.015 * risk)
    maybe("malignancy", 0.04 * risk)
    maybe("retinopathy_prolif", 0.03)

    # Medications (active = blank STOP)
    def med(name, cls, p, stopped_days_ago=None):
        if random.random() < p:
            meds.append({"START": d(random.randint(100, 3000)),
                         "STOP": d(stopped_days_ago) if stopped_days_ago else "",
                         "PATIENT": pid, "ENCOUNTER": "", "CODE": f"MOCK-{name.upper().replace(' ', '-')}",
                         "DESCRIPTION": name, "DRUG_CLASS": cls})
    if dx == "t2dm":
        med("metformin 1000 MG BID", "biguanide", 0.70)
        med("sitagliptin 100 MG", "dpp4_inhibitor", 0.12)
        med("semaglutide 1 MG weekly", "glp1_agonist", 0.08)
        med("liraglutide 1.8 MG", "glp1_agonist", 0.03, stopped_days_ago=random.randint(10, 200))
        med("insulin glargine", "insulin", 0.20)
        med("empagliflozin 10 MG", "sglt2_inhibitor", 0.10)
    elif dx == "t1dm":
        med("insulin glargine", "insulin", 0.95)

def write(name, rows):
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

write("patients.csv", patients)
write("observations.csv", obs)
write("conditions.csv", conds)
write("medications.csv", meds)
with open(os.path.join(OUT, "codes.json"), "w") as f:
    json.dump(CODES, f, indent=2)
print(f"patients={len(patients)} observations={len(obs)} conditions={len(conds)} medications={len(meds)}")
