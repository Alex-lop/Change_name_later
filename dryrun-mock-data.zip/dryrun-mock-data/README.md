# Dry Run — mock data pack

Drop this whole folder into the repo as `data/`. Everything is synthetic (no real patients).

## What's here

```
patients/              Synthea-shaped CSVs (same column names as real Synthea export)
  patients.csv         Id, BIRTHDATE, GENDER, RACE, ETHNICITY, STATE, COUNTY
  observations.csv     DATE, PATIENT, CODE (LOINC), VALUE, UNITS
  conditions.csv       START, STOP, PATIENT, CODE (SNOMED), DESCRIPTION
  medications.csv      START, STOP, PATIENT, CODE, DESCRIPTION, DRUG_CLASS (mock-only column)
  codes.json           Every code used, with descriptions
trials/                3 real T2D Phase 3 trials + pre-parsed rules ("cached LLM output")
  NCT02692716.json     PIONEER 6        — criteria text COMPLETE
  NCT03987919.json     SURPASS-2        — criteria text PARTIAL
  NCT01131676.json     EMPA-REG OUTCOME — criteria text PARTIAL
generate_mock.py       Regenerate patients: python generate_mock.py 10000
```

## Ground rules baked into the data

- **Index date = 2026-10-01.** All `lookback_days` / `within_days` windows count back from it.
- **Labs missing ~10–20% of the time** → engine must return `unknown`, never `meets`.
- **Some labs are older than the lookback window** → also `unknown`.
- **25% of HbA1c values are in mmol/mol**, the rest in %. Convert to % before comparing:
  `% = mmol_mol / 10.929 + 2.15`. Compare at 1 decimal place.
- **Conditions & meds:** absence of a record = patient does NOT have it (verdict `fails` for `has`), not `unknown`.
- **Active med** = STOP is blank, or STOP is within the window being checked.

## Rule schema

```json
{
  "rule_id": "S2-I2",
  "kind": "inclusion | exclusion",
  "status": "mapped | not_evaluable",
  "source_text": "exact sentence from the trial",
  "field": "age | lab | condition | medication",
  "operator": ">= | <= | < | > | between | has | has_within_days | active | active_within_days | active_for_at_least_days",
  "value": 7.0, "value_high": 10.5, "unit": "%",
  "code": "LOINC for labs", "codes": ["SNOMED for conditions"], "drug_classes": ["for meds"],
  "lookback_days": 90,
  "negate": false,
  "logic": "any_of | all_of",   "children": [ ...nested rules... ],
  "approximation": "where the mapping is looser than the text",
  "reason": "why a rule is not_evaluable"
}
```

- `not_evaluable` rules are **skipped by the engine** and counted in the coverage score.
- Exclusions use `negate: true`: negate flips meets↔fails, **unknown stays unknown**.
- Compound rules: `all_of` = Kleene AND, `any_of` = Kleene OR.

## TODO for the code
1. Replace PARTIAL criteria text with the live API: `GET https://clinicaltrials.gov/api/v2/studies/{NCT}` → `protocolSection.eligibilityModule.eligibilityCriteria`.
2. `MOCK-*` codes and `DRUG_CLASS` don't exist in real Synthea — map meds to classes by name when switching to real data.
